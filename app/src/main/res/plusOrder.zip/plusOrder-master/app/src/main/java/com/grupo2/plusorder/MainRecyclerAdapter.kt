package com.grupo2.plusorder

import android.content.Context
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.grupo2.plusorder.backend.models.Prato
import com.grupo2.plusorder.backend.tables.BackendPrato



 class MainRecyclerAdapter(val pratos: List<Prato>, val context: Context) :
    RecyclerView.Adapter<MainRecyclerAdapter.MyViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.ementa_prato,
            parent,false)
        return MyViewHolder(itemView)

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val currentitem = pratos[position]

        holder.nomePrato.text = currentitem.nome

    }

    override fun getItemCount(): Int {

        return pratos.size
    }


    class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){

        val nomePrato : TextView = itemView.findViewById(R.id.NomePrato)
        val imagemPrato : ImageView = itemView.findViewById(R.id.ImagemPrato)

    }

}