package com.grupo2.plusorder

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL
import androidx.recyclerview.widget.RecyclerView
import com.grupo2.plusorder.backend.models.Prato
import com.grupo2.plusorder.backend.tables.BackendPrato
import com.grupo2.plusorder.databinding.FragmentEmentaBinding
import com.grupo2.plusorder.databinding.LoginActivityBinding
import kotlinx.android.synthetic.main.fragment_ementa.*
import java.util.*
import kotlin.collections.ArrayList


class EmentaFragment : Fragment() {

    private lateinit var pratoRecyclerview : RecyclerView
    private lateinit var pratoArrayList : ArrayList<Prato>

    private var _binding: FragmentEmentaBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_ementa, container, false)
        // Inflate the layout for this fragment

        //Help

        var itens : MutableList<Prato> = arrayListOf()
        var pratos = BackendPrato.GetAllPratos()
        for (prato in pratos)
            itens.add(prato)

        val recicla : RecyclerView = view.findViewById(R.id.EmentaRecycler)
        val adapta = MainRecyclerAdapter(itens, requireActivity())

        recicla.layoutManager = LinearLayoutManager(requireActivity(), HORIZONTAL, false)

        recicla.adapter = adapta




        return view

    }



}