package com.grupo2.plusorder

class Categoria (var nome: String){
}