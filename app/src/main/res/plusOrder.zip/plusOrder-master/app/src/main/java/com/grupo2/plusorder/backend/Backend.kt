package com.grupo2.plusorder.backend

object Backend {
    const val BASE_API = "https://4bcc-87-196-51-174.eu.ngrok.io/"
}