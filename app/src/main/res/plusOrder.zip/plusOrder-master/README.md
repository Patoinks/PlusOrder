# plusOrder

### Naming Conventions
Ver: plusorder/app/src/main/java/com/grupo2/plusorder/NAMING_CONVENTIONS
